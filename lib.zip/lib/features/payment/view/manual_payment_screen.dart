import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:skill_grow/core/colors/app_colors.dart';
import 'package:skill_grow/core/widgets/snackbar.dart';
import 'package:skill_grow/core/widgets/texts.dart';
import 'package:skill_grow/features/payment/service/manual_payment_service.dart';

class ManualPaymentScreen extends StatefulWidget {
  const ManualPaymentScreen({Key? key}) : super(key: key);

  @override
  State<ManualPaymentScreen> createState() => _ManualPaymentScreenState();
}

class _ManualPaymentScreenState extends State<ManualPaymentScreen> {
  final TextEditingController _accountController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  final ImagePicker _imagePicker = ImagePicker();
  final ManualPaymentService _manualPaymentService = ManualPaymentService();

  String? _selectedPaymentMethod;
  File? _paymentReceipt;
  bool _isSubmitting = false;

  final List<Map<String, String>> _paymentMethods = [
    {'label': 'Vodafone Cash', 'value': 'vodafone_cash'},
    {'label': 'InstaPay', 'value': 'instapay'},
    {'label': 'Iraqi Master', 'value': 'iraqi_master'},
    {'label': 'Binance', 'value': 'binance'},
    {'label': 'Barq Wallet', 'value': 'barq_wallet'},
    {'label': 'Mobily Pay', 'value': 'mobily_pay'},
    {'label': 'Al Rajhi Bank', 'value': 'alrajhi_bank'},
  ];

  @override
  void dispose() {
    _accountController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _pickReceiptImage() async {
    final XFile? result = await _imagePicker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );
    if (result != null) {
      setState(() {
        _paymentReceipt = File(result.path);
      });
    }
  }

  bool _validateInputs() {
    if (_selectedPaymentMethod == null) {
      customSnackbar(
        title: 'خطأ',
        message: 'اختر طريقة الدفع أولاً.',
        type: CustomSnackbarType.failed,
      );
      return false;
    }

    if (_accountController.text.trim().isEmpty) {
      customSnackbar(
        title: 'خطأ',
        message: 'أدخل رقم الحساب أو رقم التحويل.',
        type: CustomSnackbarType.failed,
      );
      return false;
    }

    if (_amountController.text.trim().isEmpty) {
      customSnackbar(
        title: 'خطأ',
        message: 'أدخل المبلغ.',
        type: CustomSnackbarType.failed,
      );
      return false;
    }

    final double? amount = double.tryParse(_amountController.text.trim());
    if (amount == null || amount <= 0) {
      customSnackbar(
        title: 'خطأ',
        message: 'أدخل مبلغًا صالحًا أكبر من صفر.',
        type: CustomSnackbarType.failed,
      );
      return false;
    }

    if (_paymentReceipt == null) {
      customSnackbar(
        title: 'خطأ',
        message: 'اختر صورة الإيصال من المعرض.',
        type: CustomSnackbarType.failed,
      );
      return false;
    }

    return true;
  }

  Future<void> _submitManualPayment() async {
    if (!_validateInputs()) {
      return;
    }

    setState(() {
      _isSubmitting = true;
    });

    try {
      final response = await _manualPaymentService.submitManualPayment(
        paymentMethod: _selectedPaymentMethod!,
        accountNumber: _accountController.text.trim(),
        amount: _amountController.text.trim(),
        paymentReceipt: _paymentReceipt!,
      );

      _showSuccessDialog(response);
    } on ManualPaymentException catch (error) {
      customSnackbar(
        title: 'فشل',
        message: error.message,
        type: CustomSnackbarType.failed,
      );
    } catch (error) {
      customSnackbar(
        title: 'فشل',
        message: 'حدث خطأ أثناء إرسال الدفع. حاول مرة أخرى.',
        type: CustomSnackbarType.failed,
      );
    } finally {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
      }
    }
  }

  void _showSuccessDialog(ManualPaymentResponseModel response) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('تم إرسال الدفع بنجاح'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('رقم الطلب: ${response.orderId}'),
              const SizedBox(height: 8),
              Text('رقم الفاتورة: ${response.invoiceId}'),
              const SizedBox(height: 8),
              Text('حالة الدفع: ${response.paymentStatus}'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('حسناً'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.scaffoldBackgroundColor,
        elevation: 0,
        iconTheme: IconThemeData(color: AppColors.titleTextColor),
        title: GlobalText(
          text: 'دفع يدوي',
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.bold,
            color: AppColors.titleTextColor,
          ),
        ),
        centerTitle: true,
      ),
      backgroundColor: AppColors.scaffoldBackgroundColor,
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                GlobalText(
                  text: 'اختر طريقة الدفع',
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                    color: AppColors.titleTextColor,
                  ),
                ),
                SizedBox(height: 8.h),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12.w),
                  decoration: BoxDecoration(
                    color: AppColors.cardBackgroundColor,
                    borderRadius: BorderRadius.circular(12.r),
                    border: Border.all(color: AppColors.textFieldBorderColor),
                  ),
                  child: DropdownButtonFormField<String>(
                    value: _selectedPaymentMethod,
                    decoration: const InputDecoration(border: InputBorder.none),
                    hint: const Text('اختر طريقة الدفع'),
                    items: _paymentMethods.map((method) {
                      return DropdownMenuItem<String>(
                        value: method['value'],
                        child: Text(method['label'] ?? ''),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedPaymentMethod = value;
                      });
                    },
                  ),
                ),
                SizedBox(height: 16.h),
                GlobalText(
                  text: 'رقم الحساب أو رقم التحويل',
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                    color: AppColors.titleTextColor,
                  ),
                ),
                SizedBox(height: 8.h),
                TextFormField(
                  controller: _accountController,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: AppColors.cardBackgroundColor,
                    hintText: 'أدخل رقم الحساب أو التحويل',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.r),
                      borderSide:
                          BorderSide(color: AppColors.textFieldBorderColor),
                    ),
                  ),
                ),
                SizedBox(height: 16.h),
                GlobalText(
                  text: 'المبلغ',
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                    color: AppColors.titleTextColor,
                  ),
                ),
                SizedBox(height: 8.h),
                TextFormField(
                  controller: _amountController,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: AppColors.cardBackgroundColor,
                    hintText: 'أدخل المبلغ',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.r),
                      borderSide:
                          BorderSide(color: AppColors.textFieldBorderColor),
                    ),
                  ),
                ),
                SizedBox(height: 16.h),
                GlobalText(
                  text: 'صورة الإيصال',
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                    color: AppColors.titleTextColor,
                  ),
                ),
                SizedBox(height: 8.h),
                GestureDetector(
                  onTap: _pickReceiptImage,
                  child: Container(
                    height: 220.h,
                    decoration: BoxDecoration(
                      color: AppColors.cardBackgroundColor,
                      borderRadius: BorderRadius.circular(12.r),
                      border: Border.all(color: AppColors.textFieldBorderColor),
                    ),
                    child: _paymentReceipt == null
                        ? Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.image_outlined,
                                size: 50.sp,
                                color: AppColors.inactiveIconColor,
                              ),
                              SizedBox(height: 8.h),
                              GlobalText(
                                text: 'اضغط لاختيار صورة الإيصال من المعرض',
                                style: TextStyle(
                                  fontSize: 13.sp,
                                  color: AppColors.inactiveIconColor,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          )
                        : ClipRRect(
                            borderRadius: BorderRadius.circular(12.r),
                            child: Image.file(
                              _paymentReceipt!,
                              fit: BoxFit.cover,
                              width: double.infinity,
                            ),
                          ),
                  ),
                ),
                SizedBox(height: 24.h),
                ElevatedButton(
                  onPressed: _isSubmitting ? null : _submitManualPayment,
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 16.h),
                    backgroundColor: AppColors.primaryColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                  ),
                  child: _isSubmitting
                      ? SizedBox(
                          height: 20.h,
                          width: 20.h,
                          child: const CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : GlobalText(
                          text: 'إرسال الدفع',
                          style: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                ),
              ],
            ),
          ),
          if (_isSubmitting)
            Container(
              color: Colors.black.withOpacity(0.25),
              child: const Center(
                child: CircularProgressIndicator(),
              ),
            ),
        ],
      ),
    );
  }
}
